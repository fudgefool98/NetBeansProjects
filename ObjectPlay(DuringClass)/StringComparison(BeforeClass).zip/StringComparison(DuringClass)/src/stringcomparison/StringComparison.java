/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringcomparison;

/**
 *
 * @author Professor Wergeles
 */
public class StringComparison {

    /**
     * @notes 
     */
    public static void main(String[] args) {
        

        
  
        System.out.println("name: \"" + name + "\"");
        System.out.println("name2: \"" + name2 + "\"");
        
        
        if () System.out.println("They are equal!");
        else System.out.println("They are not equal!");   
        
        
        if () System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if () System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if ( ) System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if ( ) System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if () System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if() System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if() System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if() System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        
        if() System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
        System.out.println("\nname.equals(name2):");
        
        if() System.out.println("They are equal!");
        else System.out.println("They are not equal!");
        
    }
}


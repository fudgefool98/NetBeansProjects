///

//I HAVE NO IDEA WHAT I'M DOING BUT I THOUGHT THAT TURNING SOMETHING IN WAS BETTER THAN NOTHING






//*
//// * To change this license header, choose License Headers in Project Properties.
//// * To change this template file, choose Tools | Templates
//// * and open the template in the editor.
//// */
////
////
////Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
//// *
//// * Redistribution and use in source and binary forms, with or without
//// * modification, are permitted provided that the following conditions
//// * are met:
//// *
//// *   - Redistributions of source code must retain the above copyright
//// *     notice, this list of conditions and the following disclaimer.
//// *
//// *   - Redistributions in binary form must reproduce the above copyright
//// *     notice, this list of conditions and the following disclaimer in the
//// *     documentation and/or other materials provided with the distribution.
//// *
//// *   - Neither the name of Oracle or the names of its
//// *     contributors may be used to endorse or promote products derived
//// *     from this software without specific prior written permission.
//// *
//// * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
//// * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
//// * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
//// * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
//// * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//// * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//// * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//// * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//// * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//// * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//// * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//// */
package documenteditor;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.*
import java.io.File;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.HTMLEditor;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JFileChooser;

/**
 *
 * @author Jordan
 */
public class Documenteditor extends Application {
    public String title = "document editor";
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle(title);
        
        VBox root = new VBox(20);
        
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setVgap(20);
        
        Label titleLabel = new Label("Title:");
        TextField titleField = new TextField();
        titleField.setPrefColumnCount(45);
        HBox titleFieldBox = new HBox(10);
        titleFieldBox.setAlignment(Pos.CENTER_LEFT);
        titleFieldBox.getChildren().addAll(titleLabel, titleField);
        
        grid.add(titleFieldBox,0,0);
        
        
//        HTMLEditor editor = new HTMLEditor();
//        editor.setPrefSize(600,500);
//        root.add(editor,0,1);

        TextArea editor = new TextArea();
        editor.setPrefColumnCount(45);
        editor.setPrefRowCount(25);
        grid.add(editor,0,1);

        
        
        Button saveButton = new Button("Save");
        HBox saveButtonBox = new HBox();
        saveButtonBox.setAlignment(Pos.CENTER_RIGHT);
        saveButtonBox.getChildren().add(saveButton);
        
        
        saveButton.setRotate(45);
        
       
        grid.add(saveButtonBox, 0, 2);
        
        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("file");
        menuBar.getMenus().add(fileMenu);
        MenuItem openMenuItem = new MenuItem ("Open");
        fileMenu.getItems().add(openMenuItem);
        
        openMenuItem.setOnAction((ActionEvent event) ->{
            System.out.println("Open Chosen");
        });
        
        root.getChildren().add(menuBar);
        root.getChildren().add(grid);
        
        FileChooser.ExtensionFilter        
        Scene scene = new Scene(root,800,700);
    }
        public void actionPerformed(java.awt.event.ActionEvent e) {

        //Handle open button action.
        if (e.getSource() == openButton) {
            int returnVal = fc.showOpenDialog(FileChooserDemo.this);

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                //This is where a real application would open the file.
                log.append("Opening: " + file.getName() + "." + newline);
            } else {
                log.append("Open command cancelled by user." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());

        //Handle save button action.
        } else if (e.getSource() == saveButton) {
            int returnVal = fc.showSaveDialog(FileChooserDemo.this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                //This is where a real application would save the file.
                log.append("Saving: " + file.getName() + "." + newline);
            } else {
                log.append("Save command cancelled by user." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());
        }
    }
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}






